package com.example.dragansmolcic.quizapp;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.text.TextUtils;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class Register extends AppCompatActivity implements View.OnClickListener{

    private Button buttonRegister;
    private EditText editTextEmail;
    private EditText editTextPassword;
    private TextView textViewLogIn;
    private ProgressBar progressBar;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();
        if (firebaseAuth.getCurrentUser() != null){
            finish();
            startActivity(new Intent(getApplicationContext(), MainActivity.class));

        }



        buttonRegister = (Button) findViewById(R.id.buttonRegister);
        editTextEmail = (EditText) findViewById(R.id.editTextEmail);
        editTextPassword = (EditText) findViewById(R.id.editTextPassword);
        textViewLogIn =(TextView) findViewById(R.id.textViewLogIn);

        buttonRegister.setOnClickListener(this);
        textViewLogIn.setOnClickListener(this);
    }


    private void registerUser() {


        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        if (TextUtils.isEmpty(email)) {
            //Email is empty
            return;
        }

        if (TextUtils.isEmpty(password)) {
            //Password is empty
            return;
        }



        firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if (task.isSuccessful())
                {
                  //Registration is successful
                    Toast.makeText(Register.this, "Registered successfully", Toast.LENGTH_SHORT).show();
                    Intent OpenMainActivity = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(OpenMainActivity);

                }
                else
                {
                    Toast.makeText(Register.this, "Could not register. Please try again.", Toast.LENGTH_SHORT).show();

                }
            }
        });
}

    @Override
    public void onClick(View view) {


        if (view == buttonRegister ){
            registerUser();

        }

        if (view == textViewLogIn ){
            registerUser();
            startActivity(new Intent(getApplicationContext(), LogInActivity.class));
        }
    }
}
