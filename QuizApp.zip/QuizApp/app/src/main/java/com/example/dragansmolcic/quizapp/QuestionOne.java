package com.example.dragansmolcic.quizapp;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;

public class QuestionOne extends AppCompatActivity {

    private TextView mTextMessage;

    public static TextView data;
    public static TextView QuestionOneText;
    public static Button Answer1;
    public static Button Answer2;
    public static Button Answer3;
    public static Button Answer4;
    public static String CorrectAnswer;
    String SelectedAnswer;
    static int cnt = 0;
    static int NumberOfQuestions;



    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_dashboard:
                    mTextMessage.setText(R.string.title_dashboard);
                    return true;
                case R.id.navigation_notifications:
                    mTextMessage.setText(R.string.title_notifications);
                    return true;
            }
            return false;
        }
    };





   /* public void OpenQuestionTwo (View view)
    {

        Intent OpenQuestionTwo = new Intent (this, QuestionTwoo.class);
        startActivity(OpenQuestionTwo);


    }*/

   public void OpenQuestionOne (View view)
    {
        if (NumberOfQuestions!=0) {
            Intent OpenQuestionOne = new Intent(this, QuestionOne.class);
            startActivity(OpenQuestionOne);
            NumberOfQuestions--;
        }

        if (NumberOfQuestions==0) {
            Intent OpenEndScreen = new Intent(this, EndScreen.class);
            startActivity(OpenEndScreen);

        }


    }


    public void RateAnswer1 (View view)
    {
            if (Answer1.getText().toString()==CorrectAnswer){

                MainActivity.score ++;


            }


    }


    public void AnswerOneClicked (View view){

        RateAnswer1(null);
        //OpenQuestionTwo(null);
        cnt = cnt + 1;
        OpenQuestionOne(null);



    }

    public void RateAnswer2 (View view)
    {
        if (Answer2.getText().toString()==CorrectAnswer){

            MainActivity.score ++;


        }

    }


    public void AnswerTwoClicked (View view){

        RateAnswer2(null);
        cnt = cnt + 1;
        OpenQuestionOne(null);


    }

    public void RateAnswer3 (View view)
    {
        if (Answer3.getText().toString()==CorrectAnswer){

            MainActivity.score ++;


        }

    }


    public void AnswerThreeClicked (View view){

        RateAnswer3(null);
        cnt = cnt + 1;
        OpenQuestionOne(null);


    }

    public void RateAnswer4 (View view)
    {
        if (Answer4.getText().toString()==CorrectAnswer){

            MainActivity.score ++;


        }


    }


    public void AnswerFourClicked (View view){

        RateAnswer4(null);
        cnt = cnt + 1;
        OpenQuestionOne(null);


    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_one);

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        QuestionOneText = (TextView) findViewById(R.id.QuestionOneText);

        String AnswerOne;
        String AnswerTwo;
        String AnswerThree;
        String AnswerFour;



        Answer1 = (Button) findViewById(R.id.answer1);
        Answer2 = (Button) findViewById(R.id.answer2);
        Answer3 = (Button) findViewById(R.id.answer3);
        Answer4 = (Button) findViewById(R.id.answer4);

      LoadQuestions process = new LoadQuestions();
      process.execute();

      CorrectAnswer = process.correct_answer[QuestionOne.cnt];






    }


}
