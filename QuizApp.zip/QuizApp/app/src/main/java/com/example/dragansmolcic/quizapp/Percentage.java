package com.example.dragansmolcic.quizapp;

/**
 * Created by dragan.smolcic on 11/9/2018.
 */

public class Percentage {


    public int getPercentage(int NumberOfQuestions, int NumberOfCorrect)
        {
            float NOQ = NumberOfQuestions;
            float NOCQ = NumberOfCorrect;
            float Result = (NOCQ/NOQ)*100;


            return (Math.round(Result));


        }
}
