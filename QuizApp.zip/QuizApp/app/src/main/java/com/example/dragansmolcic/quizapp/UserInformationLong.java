package com.example.dragansmolcic.quizapp;

/**
 * Created by dragan.smolcic on 11/10/2018.
 */

public class UserInformationLong {

    public long lastScore;
    public long lastPercentage;

    public UserInformationLong()
    {


    }
}
