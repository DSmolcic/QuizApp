package com.example.dragansmolcic.quizapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.util.Scanner;

import android.widget.TextView;
import android.widget.Button;


/**
 * Created by dragan.smolcic on 7/27/2018.
 */

public class LoadQuestionsTwo extends AsyncTask <Void, Void, Void> {
    String data = "";
    String question = "";
    String correct_answer = "";
    String incorrect_answer = "";
    String [] incorrect_answers = new String[4];
    int incorrect_anwers_counter;




    @Override
    protected Void doInBackground(Void... voids) {

        try {


            Scanner sc = new Scanner(System.in);
            Socket s = new Socket("10.0.2.2", 1342);
            Scanner sc1 = new Scanner(s.getInputStream());


            while(sc1.hasNext())
            {
                data=sc1.nextLine();
            }
            MainActivity.data=data;

            JSONObject JO = new JSONObject(data);




        }

        catch (MalformedURLException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }


        return null;
    }


    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);




    }
}
