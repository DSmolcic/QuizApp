package com.example.dragansmolcic.quizapp;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import android.widget.TextView;
import android.widget.Button;
import java.util.Scanner;
import java.net.Socket;


/**
 * Created by dragan.smolcic on 7/27/2018.
 */

public class LoadQuestions extends AsyncTask <Void, Void, Void>  {
    String data = "";
    String [] question = new String [50];
    String [] correct_answer = new String [50];
    String incorrect_answer = "";
    String [][] incorrect_answers = new String[50][4];
    int incorrect_anwers_counter;




    @Override
    protected Void doInBackground(Void... voids) {

        try {



       /*  Scanner sc = new Scanner(System.in);
           Socket s = new Socket("10.0.2.2", 1342);
           Scanner sc1 = new Scanner(s.getInputStream());
           //PrintStream p = new PrintStream(s.getOutputStream());
          // data=sc1.next();

            while(sc1.hasNext())
            {
                data=sc1.nextLine();
            }*/




            JSONObject JO = new JSONObject(MainActivity.data);

            JSONArray JA = JO.getJSONArray("results");
           for (int i = 0; i < JA.length(); i++)
           {

               JO = (JSONObject) JA.get(i);


               question[i] = String.valueOf(JO.get("question"));

           }

            for (int j = 0; j < JA.length(); j++)
            {

                JO = (JSONObject) JA.get(j);


                correct_answer[j] = String.valueOf(JO.get("correct_answer"));

            }

               // JO = (JSONObject) JA.get(QuestionOne.cnt);


             //JSONArray JAIA = JO.getJSONArray("incorrect_answers");



            for (int o = 0; o < JA.length(); o++) {

                JO = (JSONObject) JA.get(o);
                JSONArray JAIA = JO.getJSONArray("incorrect_answers");
                for (int k = 0; k < JAIA.length(); k++) {

                    // JO = (JSONObject) JAIA.get(k);


                    incorrect_answer = String.valueOf(JAIA.get(k));


                    incorrect_answers[o][k] = incorrect_answer;


                }

            }



        }

        /*catch (MalformedURLException e){
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }*/ catch (JSONException e) {
            e.printStackTrace();
    }


        return null;
    }


    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);

        QuestionOne.QuestionOneText.setText(this.question[QuestionOne.cnt]);

        int k = 0;

        while (incorrect_answers[QuestionOne.cnt][k]!=null) {


            incorrect_anwers_counter ++;

            k++;
        }



        LoadAnswers process2 = new LoadAnswers();

        if (incorrect_anwers_counter ==3) {

            String [] Answer1234 = new String[4];
            Answer1234 = process2.FourAnswers(correct_answer[QuestionOne.cnt], incorrect_answers[QuestionOne.cnt][0], incorrect_answers[QuestionOne.cnt][1], incorrect_answers[QuestionOne.cnt][2]);
            QuestionOne.CorrectAnswer=correct_answer[QuestionOne.cnt];


            QuestionOne.Answer1.setText(Answer1234[0]);
            QuestionOne.Answer2.setText(Answer1234[1]);
            QuestionOne.Answer3.setText(Answer1234[2]);
            QuestionOne.Answer4.setText(Answer1234[3]);
            incorrect_anwers_counter = 0;




        }


        if (incorrect_anwers_counter ==1) {
            process2.TwoAnswers(correct_answer[QuestionOne.cnt], incorrect_answers[QuestionOne.cnt][0]);

            String [] Answer12 = new String[2];
            Answer12 = process2.TwoAnswers(correct_answer[QuestionOne.cnt], incorrect_answers[QuestionOne.cnt][0]);


            QuestionOne.Answer1.setText(Answer12[0]);
            QuestionOne.Answer2.setText(Answer12[1]);
            QuestionOne.Answer3.setVisibility(View.INVISIBLE);
            QuestionOne.Answer4.setVisibility(View.INVISIBLE);
            incorrect_anwers_counter = 0;

        }





    }
}
