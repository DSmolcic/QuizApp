package com.example.dragansmolcic.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.common.server.converter.StringToIntConverter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserInfo;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class EndScreen extends AppCompatActivity implements View.OnClickListener{


    private DatabaseReference databaseReference;
    private FirebaseAuth firebaseAuth;

    public static Button buttonPlayAgain;

    public static UserInformation userInfo = new UserInformation();

    public static TextView previousScoreText;
    public static TextView previousPercentageText;

    public static TextView finalScoreText;
    public static TextView finalPercentageText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_end_screen);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        final List<UserInformation> allUsers = new ArrayList<UserInformation>();

        finalScoreText = (TextView) findViewById(R.id.final_score_displayed);
        finalPercentageText = (TextView) findViewById(R.id.final_percentage_displayed);
        buttonPlayAgain = (Button) findViewById(R.id.buttonPlayAgain);

        Percentage finalPercentage = new Percentage();
        int percentage = finalPercentage.getPercentage(MainActivity.NumberOfQuestionsUnchanging, MainActivity.score);


        finalScoreText.setText ("You have answered " + Integer.toString(MainActivity.score) + "\n questions correctly out of " + MainActivity.NumberOfQuestionsUnchanging + ".");
        finalPercentageText.setText ("You have answered " + Integer.toString(percentage) + "\n% of the questions correctly.");


        FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();
        String userid=user.getUid();
        databaseReference = FirebaseDatabase.getInstance().getReference(userid);

       /* databaseReference.child(userid).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                Iterable<DataSnapshot> children = dataSnapshot.getChildren();

                for (DataSnapshot child : children){

                    long temp = child.getValue(long.class);
                    previousPercentageText.setText("The last time you played, your percentage was " + Long.toString(temp) + ".");
                    return;

                    //UserInformationLong value = child.getValue(UserInformationLong.class);
                    //userInfo = value;
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });*/



        databaseReference.child(userid).addValueEventListener(new ValueEventListener() {
           @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                Iterable<DataSnapshot> children = dataSnapshot.getChildren();

                for (DataSnapshot child : children){
                    long temp = child.getValue(long.class);
                    previousPercentageText = (TextView) findViewById(R.id.previous_percentage_displayed);
                    previousPercentageText.setText("The last time you played, your percentage was " + Long.toString(temp) + ".");
                    return;
                    //UserInformation value = child.getValue(UserInformation.class);
                    //userInfo = value;

                    /*UserInformation userInformation = child.getValue(UserInformation.class);

                    allUsers.add(userInformation);*/
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });





        //previousPercentageText.setText("Your previous score was " + userInfo.getLastPercentage() + ".");

        //SaveUserInformation();


    }

    private void SaveUserInformation()
    {

        UserInformation userInformation = new UserInformation(MainActivity.score, MainActivity.NumberOfQuestionsUnchanging);

        firebaseAuth = FirebaseAuth.getInstance();

        FirebaseUser uuser = firebaseAuth.getCurrentUser();

        databaseReference.child(uuser.getUid()).setValue(userInformation);







    }







    @Override
    public void onClick(View view) {

        if (view == buttonPlayAgain)
        {
            SaveUserInformation();
            MainActivity.score=0;
            MainActivity.NumberOfQuestionsUnchanging=0;
            startActivity(new Intent(getApplicationContext(), MainActivity.class));

        }

    }
}
