package com.example.dragansmolcic.quizapp;

/**
 * Created by dragan.smolcic on 7/28/2018.
 */

import android.os.AsyncTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import java.util.Collections;
import java.util.List;
import java.util.Arrays;

public class LoadAnswers{


    public String[] FourAnswers (String One, String Two, String Three, String Four)
    {

            String [] Answers = new String[4];

            Answers[0] = One;
            Answers[1] = Two;
            Answers[2] = Three;
            Answers[3] = Four;



        List myList = Arrays.asList(Answers);
        //System.out.println("\nOriginal list: " + myList);

        Collections.shuffle(myList);
       // System.out.println("First shuffled list: " + myList);

        Collections.shuffle(myList);
        //System.out.println("Second shuffled list: " + myList);

        // CONVERTING LIST BACK TO ARRAY
        Object str[] = myList.toArray();

        Answers[0] = str[0].toString();
        Answers[1] = str[1].toString();
        Answers[2] = str[2].toString();
        Answers[3] = str[3].toString();

        return Answers;



    }

    public String[] ThreeAnswers (String One, String Two, String Three)
    {

        String [] Answers = new String[3];

        Answers[0] = One;
        Answers[1] = Two;
        Answers[2] = Three;




        List myList = Arrays.asList(Answers);
        //System.out.println("\nOriginal list: " + myList);

        Collections.shuffle(myList);
        // System.out.println("First shuffled list: " + myList);

        Collections.shuffle(myList);
        //System.out.println("Second shuffled list: " + myList);

        // CONVERTING LIST BACK TO ARRAY
        Object str[] = myList.toArray();

        Answers[0] = str[0].toString();
        Answers[1] = str[1].toString();
        Answers[2] = str[2].toString();


        return Answers;



    }

    public String[] TwoAnswers (String One, String Two)
    {

        String [] Answers = new String[2];

        Answers[0] = One;
        Answers[1] = Two;





        List myList = Arrays.asList(Answers);
        //System.out.println("\nOriginal list: " + myList);

        Collections.shuffle(myList);
        // System.out.println("First shuffled list: " + myList);

        Collections.shuffle(myList);
        //System.out.println("Second shuffled list: " + myList);

        // CONVERTING LIST BACK TO ARRAY
        Object str[] = myList.toArray();

        Answers[0] = str[0].toString();
        Answers[1] = str[1].toString();



        return Answers;



    }



}
