package com.example.dragansmolcic.quizapp;

import android.view.ViewDebug;

/**
 * Created by dragan.smolcic on 11/9/2018.
 */

public class UserInformation {

    public String lastScore;
    public String lastPercentage;



    public UserInformation()
    {}

    public UserInformation(int score)
    {

        lastScore = Integer.toString(score);

        Percentage perc = new Percentage();
        int p = perc.getPercentage(score, MainActivity.score);

        lastPercentage = Integer.toString(p);

    }

    public UserInformation(int score, int allQuestions)
        {

            lastScore = Integer.toString(score);

            Percentage perc = new Percentage();
            int p = perc.getPercentage(score, allQuestions);

            lastPercentage = Integer.toString(p);

        }

        public String getLastScore()
        {
            return lastScore;

        }

    public void setLastScore(String Score)
    {
        lastScore = Score;

    }

    public int getLastPercentage()
            {

                Percentage perc = new Percentage();
                int p = perc.getPercentage(MainActivity.NumberOfQuestionsUnchanging, MainActivity.score);

                return p;
            }

    public void setLastPercentage()
    {

        Percentage perc = new Percentage();
        int p = perc.getPercentage(MainActivity.NumberOfQuestionsUnchanging, MainActivity.score);

        lastPercentage = Integer.toString(p);
    }

}


