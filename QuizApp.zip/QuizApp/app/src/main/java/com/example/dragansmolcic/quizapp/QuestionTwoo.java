package com.example.dragansmolcic.quizapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class QuestionTwoo extends AppCompatActivity {

    private TextView mTextMessage;
    public static TextView data;
    public static TextView QuestionTwoText;
    public static Button Answer1;
    public static Button Answer2;
    public static Button Answer3;
    public static Button Answer4;
    String CorrectAnswer;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_dashboard:
                    mTextMessage.setText(R.string.title_dashboard);
                    return true;
                case R.id.navigation_notifications:
                    mTextMessage.setText(R.string.title_notifications);
                    return true;
            }
            return false;
        }
    };


    public void OpenQuestionThree (View view)
    {

       // Intent OpenQuestionThree = new Intent (this, QuestionThree.class);
       // startActivity(OpenQuestionThree);

    }

    public void RateAnswer1 (View view)
    {
        if (Answer1.getText().toString()==CorrectAnswer){

            MainActivity.score ++;

        }


    }


    public void AnswerOneClicked (View view){


        OpenQuestionThree(null);
        RateAnswer1(null);

    }

    public void RateAnswer2 (View view)
    {
        if (Answer2.getText().toString()==CorrectAnswer){

            MainActivity.score ++;

        }

    }


    public void AnswerTwoClicked (View view){


        OpenQuestionThree(null);
        RateAnswer2(null);

    }

    public void RateAnswer3 (View view)
    {
        if (Answer3.getText().toString()==CorrectAnswer){

            MainActivity.score ++;

        }

    }


    public void AnswerThreeClicked (View view){


        OpenQuestionThree(null);
        RateAnswer3(null);

    }

    public void RateAnswer4 (View view)
    {
        if (Answer4.getText().toString()==CorrectAnswer){

            MainActivity.score ++;

        }


    }


    public void AnswerFourClicked (View view){


        OpenQuestionThree(null);
        RateAnswer4(null);

    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question_twoo);

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        QuestionTwoText = (TextView) findViewById(R.id.QuestionTwoText);

        Answer1 = (Button) findViewById(R.id.answer1);
        Answer2 = (Button) findViewById(R.id.answer2);
        Answer3 = (Button) findViewById(R.id.answer3);
        Answer4 = (Button) findViewById(R.id.answer4);

        LoadQuestionsTwo process = new LoadQuestionsTwo();
        process.execute();

        CorrectAnswer = process.correct_answer;
    }

}
